package com.uff.action.partenaires.test.common;

import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;

import com.uff.test.mock.AbstractServiceTest;

public abstract class AbstractBatchCaseTest extends AbstractServiceTest {

	public static class LogTestRule implements TestRule {
		@Override
		public Statement apply(Statement base, Description description) {
			return new Statement() {
				@Override
				public void evaluate() throws Throwable {
					try {
						base.evaluate();
					} catch (final Throwable th) {
						th.printStackTrace(System.err);
						throw th;
					}
				}
			};
		}
	}

	@Rule
	public LogTestRule logRule = new LogTestRule();

	@Autowired
	protected JobLauncher jobLauncher;

	@Autowired
	protected EventMessagesMock eventMessagesMock;

	protected String fullResultPath;

	protected JobExecution launch(Job job, Map<String, JobParameter> properties) throws Exception {
		final JobParametersBuilder jobParametersBuilder = new JobParametersBuilder()
				.addDate("time", new Date(1478682864553L));
		for (final Entry<String, JobParameter> e : properties.entrySet()) {
			jobParametersBuilder.addParameter(e.getKey(), e.getValue());
		}
		// Ex�cution
		final JobParameters parameters = jobParametersBuilder
				.toJobParameters();
		final JobExecution execution = jobLauncher.run(job, parameters);
		final long time = execution.getEndTime().getTime() - execution.getCreateTime().getTime();
		System.out.println(">> JobExecution executed in " + time + " ms");

		return execution;
	}

	protected void assertFailures(final JobExecution execution) {
		// Assert failures
		final List<Throwable> failures = execution.getAllFailureExceptions();
		for (final Throwable throwable : failures) {
			throwable.printStackTrace();
		}
		assertTrue(failures.isEmpty());
	}

}