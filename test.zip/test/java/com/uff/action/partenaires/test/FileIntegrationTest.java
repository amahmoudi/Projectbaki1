package com.uff.action.partenaires.test;

import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.io.Resources;
import com.uff.action.partenaires.integration.context.OutputContext;
import com.uff.action.partenaires.integration.writer.LogWriter;
import com.uff.action.partenaires.test.common.AbstractBatchCaseTest;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext(classMode = ClassMode.BEFORE_CLASS)
@ContextConfiguration({ "classpath:batchTestContext.xml" })
public class FileIntegrationTest extends AbstractBatchCaseTest {

	@Autowired
	protected Job fileIntegrationJob;
	@Autowired
	private LogWriter logWriter;

	@Test
	public void test() throws Exception {
		// Ex�cution
		final JobExecution execution = launch(fileIntegrationJob, Collections.singletonMap("url", new JobParameter(Resources.getResource("files/CRE5A001_20170626.csv").toString())));

		// V�rifications
		assertFailures(execution);

		// Assertions
		final List<OutputContext<String>> lasts = logWriter.getLasts();
		Assert.assertEquals(1, lasts.size());
		assertXML("soapTest.xml", lasts.get(0).getOutput());
	}

}
