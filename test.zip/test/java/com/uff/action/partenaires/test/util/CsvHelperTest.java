package com.uff.action.partenaires.test.util;

import org.junit.Assert;
import org.junit.Test;

import com.uff.action.partenaires.integration.csv.CsvException;
import com.uff.action.partenaires.util.CsvHelper;

public class CsvHelperTest {
	private void assertResult(String[] columns, String... expected) {
		Assert.assertEquals(expected.length + " colonnes attendues, " + columns.length + " trouv�es", expected.length, columns.length);
	}

	@Test
	public void test() {
		assertResult(CsvHelper.readColumns("Robert;Dupont;rue du Verger, 12", ';'), "Robert", "Dupont", "rue du Verger, 12");
		assertResult(CsvHelper.readColumns("\"Michel\";\"Durand\";\" av. de la Ferme, 89 \"", ';'), "Michel", "Durand", "av. de la Ferme, 89");
		assertResult(CsvHelper.readColumns("\"Michel \"\"Michele\"\"\";\"Durand\";\" av. de la Ferme, 89\"", ';'), "Michel \"Michele\"", "Durand", "av. de la Ferme, 89");
		assertResult(CsvHelper.readColumns("\"Michel;Michele\";\"Durand\";\"av. de la Ferme, 89\"", ';'), "Michel;Michele", "Durand", "av. de la Ferme, 89");
	}

	@Test(expected = CsvException.class)
	public void testEscapeCharacterAtWrongPlace() {
		CsvHelper.readColumns("Rob\"ert;Dupont;rue du Verger, 12", ';');
	}
}
