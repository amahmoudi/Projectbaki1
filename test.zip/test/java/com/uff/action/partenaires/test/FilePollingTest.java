package com.uff.action.partenaires.test;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uff.action.partenaires.test.common.AbstractBatchCaseTest;
import com.uff.events.BusinessEvent;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext(classMode = ClassMode.BEFORE_CLASS)
@ContextConfiguration({ "classpath:batchTestContext.xml" })
public class FilePollingTest extends AbstractBatchCaseTest {

	@Autowired
	protected Job pollInputJob;

	@Test
	public void test() throws Exception {
		// Ex�cution
		final JobExecution execution = launch(pollInputJob, Collections.emptyMap());

		// V�rifications
		assertFailures(execution);

		// V�rifie qu'un �v�nement a �t� cr�� avec le fichier csv en isSujet
		final List<BusinessEvent> events = eventMessagesMock.getPublished();
		Assert.assertEquals(2, events.size());
		Assert.assertEquals(new File("src/test/resources/files/test.csv").toURI().toURL().toString(), events.get(1).getIdSujet());
	}

}
