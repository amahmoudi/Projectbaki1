package com.uff.action.partenaires.test.config;

import org.junit.Assert;
import org.junit.Test;

import com.uff.action.partenaires.integration.configuration.Config;
import com.uff.action.partenaires.integration.configuration.ConfigurationReader;
import com.uff.action.partenaires.integration.configuration.FileType;
import com.uff.action.partenaires.integration.configuration.IntegrationConfig;
import com.uff.action.partenaires.integration.configuration.MappingConfig;
import com.uff.action.partenaires.integration.configuration.OutputType;
import com.uff.action.partenaires.integration.configuration.TransformationType;
import com.uff.action.partenaires.integration.csv.config.CSVMapping;

public class ConfigurationReaderTest {

	@Test
	public void testRead() throws Exception {
		final Config config = new ConfigurationReader().loadConfig("config.xml");
		Assert.assertNotNull(config);
		Assert.assertNotNull(config.getIntegrationConfigs());
		Assert.assertTrue(config.getIntegrationConfigs().size() >= 1);
		final IntegrationConfig integrationConfig = config.getIntegrationConfigs().get(0);
		Assert.assertNotNull(integrationConfig);
		Assert.assertNotNull(integrationConfig.getInput());
		Assert.assertEquals("(.*/)?CRE5A001_(.*)\\.csv", integrationConfig.getInput().getFileRegex());
		Assert.assertEquals("mapping/CRE5A001.csv.xml", integrationConfig.getInput().getMapping());
		Assert.assertEquals(FileType.CSV, integrationConfig.getInput().getType());
		final MappingConfig mappingConfig = integrationConfig.getInput().getMappingConfig();
		Assert.assertNotNull(mappingConfig);
		Assert.assertTrue(mappingConfig instanceof CSVMapping);
		Assert.assertEquals("CRE5A001", ((CSVMapping) mappingConfig).getName());
		Assert.assertNotNull(integrationConfig.getTransformation());
		Assert.assertEquals("xslt/testcre.xsl", integrationConfig.getTransformation().getFile());
		Assert.assertEquals(TransformationType.XSLT, integrationConfig.getTransformation().getType());
		Assert.assertNotNull(integrationConfig.getOutput());
		Assert.assertEquals("http://www.webservicex.net/usaddressverification.asmx?WSDL", integrationConfig.getOutput().getServiceName());
		Assert.assertEquals(OutputType.LOG, integrationConfig.getOutput().getType());
	}
}
