package com.uff.action.partenaires.test.common;

import java.util.ArrayList;
import java.util.List;

import com.uff.event.common.IEventMessages;
import com.uff.events.BusinessEvent;

public class EventMessagesMock implements IEventMessages {
	
	private final List<BusinessEvent> published = new ArrayList<>();

	@Override
	public void publish(BusinessEvent event) {
		published.add(event);
	}

	@Override
	public void consumEvent(long id, String commentaire, boolean erreur) {
	}

	public List<BusinessEvent> getPublished() {
		return published;
	}

}
